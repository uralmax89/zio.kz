<?php

    return array(

        'hooks' => array(
            'ctype_after_update',
            'ctype_after_delete',
        )

    );
