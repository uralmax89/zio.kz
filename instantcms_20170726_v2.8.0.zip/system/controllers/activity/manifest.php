<?php

    return array(

        'hooks' => array(
            'content_after_add_approve',
            'content_after_update_approve',
            'publish_delayed_content',
            'user_delete',
            'user_tab_info',
            'user_tab_show'
        )

    );
