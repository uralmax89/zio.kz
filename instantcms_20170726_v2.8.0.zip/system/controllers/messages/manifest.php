<?php

    return array(

        'hooks' => array(
            'admin_dashboard_chart',
            'menu_messages',
            'users_profile_view',
            'user_privacy_types',
            'user_delete',
            'user_notify_types'
        )

    );
