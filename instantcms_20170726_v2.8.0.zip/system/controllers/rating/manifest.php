<?php

    return array(

        'hooks' => array(
            'user_delete',
            'content_before_list'
        )

    );
