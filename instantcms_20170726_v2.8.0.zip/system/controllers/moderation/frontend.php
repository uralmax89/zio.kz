<?php
class moderation extends cmsFrontend {

    protected $useOptions = true;

}
