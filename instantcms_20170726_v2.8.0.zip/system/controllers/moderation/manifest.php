<?php

    return array(

        'hooks' => array(
            'admin_dashboard_block',
            'content_after_trash_put',
            'content_after_restore',
            'content_before_delete',
            'menu_moderation'
        )

    );
