<?php

    return array(

        'hooks' => array(
            'menu_admin',
            'user_login',
            'admin_confirm_login'
        )

    );
