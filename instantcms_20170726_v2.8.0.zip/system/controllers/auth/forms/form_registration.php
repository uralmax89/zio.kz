<?php

class formAuthRegistration extends cmsForm {

    public function init() {

        return array(

            'basic' => array(
                'type' => 'fieldset',
                'childs' => array(
                    new fieldString('email', array(
                        'title' => LANG_EMAIL,
                        'rules' => array(
                            array('required'),
                            array('email'),
                            array('unique', '{users}', 'email')
                        )
                    )),
                    new fieldString('password1', array(
                        'title' => LANG_PASSWORD,
                        'is_password' => true,
                        'rules' => array(
                            array('required'),
                            array('min_length', 6)
                        )
                    )),
                    new fieldString('password2', array(
                        'title' => LANG_RETYPE_PASSWORD,
                        'is_password' => true,
                        'rules' => array(
                            array('required'),
                            array('min_length', 6)
                        )
                    ))
                )
            )

        );

    }

}
