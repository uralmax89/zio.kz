<?php
class recaptcha extends cmsFrontend {

    protected $useOptions = true;

}
