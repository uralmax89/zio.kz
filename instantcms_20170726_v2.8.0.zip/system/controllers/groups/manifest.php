<?php

    return array(

        'hooks' => array(
            'admin_dashboard_chart',
            'content_view_hidden',
            'content_before_list',
            'rating_vote',
            'user_privacy_types',
            'user_profile_buttons',
            'user_notify_types',
            'user_delete',
            'user_tab_info',
            'user_tab_show',
            'menu_groups',
            'sitemap_sources',
            'sitemap_urls',
            'content_privacy_types',
            'content_add_permissions',
            'fulltext_search',
            'content_before_childs',
            'ctype_relation_childs',
            'admin_groups_dataset_fields_list'
        )

    );
