<?php

    return array(

        'hooks' => array(
            'content_albums_items_html',
            'fulltext_search',
            'admin_albums_ctype_menu',
            'content_albums_after_add',
            'content_albums_after_delete',
            'content_albums_item_html',
            'content_albums_before_item',
            'content_albums_before_list',
            'user_delete'
        )

    );
