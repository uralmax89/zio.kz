DELETE FROM `{#}widgets` WHERE `name` = 'visually_impaired' AND `author` = 'My-InstantCMS.Ru';
INSERT INTO `{#}widgets` (`controller`, `name`, `title`, `author`, `url`, `version`) VALUES
(NULL, 'visually_impaired', 'Версия для слабовидящих', 'My-InstantCMS.Ru', 'http://my-instantcms.ru/', '1.0.0');