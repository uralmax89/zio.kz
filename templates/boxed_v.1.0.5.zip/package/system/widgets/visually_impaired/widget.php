<?php
class widgetVisuallyImpaired extends cmsWidget {

    public function run(){

        return array();

    }

}
