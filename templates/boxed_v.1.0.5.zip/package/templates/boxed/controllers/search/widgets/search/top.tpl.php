<a class="topbar_search_button" href="javascript:void(0);"><i class="bx-search"></i></a>
<div class="topbar_search">
	<form action="<?php echo href_to('search'); ?>" method="get" class="topbar_search_form">
		<fieldset>
			<input type="search" name="q" class="form-control" placeholder="<?php html(ERR_SEARCH_QUERY_INPUT); ?>" autocomplete="off">
		</fieldset>
	</form>
	<a class="topbar_search_close" href="javascript:void(0);"><i class="bx-close"></i></a>
</div>
